#!/usr/bin/env perl
use warnings;
use strict;
use Crypt::CBC;

use Perl6::Slurp;
my $key= slurp("/home/ivo/secret.key");

(length($key)==56) or die "perl $0: Length of key is ".length($key)."\n";

my $cipher = Crypt::CBC->new( {'key' => $key,
			       'cipher'=> 'Blowfish',
			       'iv' => '12345678',
			       'regenerate_key' => 0,
			       'padding' => 'null',
			       'prepend_iv' => 0
			      });

my $ciphertext = $cipher->encrypt("Ve are secret.  Here is a longer text String to encrypt.");
# my $plaintext = $cipher->decrypt($ciphertext);

open (CFILE, '> encrypted.txt');
print CFILE $ciphertext;
close (CFILE);

print STDERR "written 'encrypted.txt'\n";
